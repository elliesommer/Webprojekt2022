<?php

namespace Database\Seeders;

use App\Models\Booking;
use App\Models\User;
use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $user = new User;
        $user->firstname = 'Elena';
        $user->lastname = 'Sommer';
        $user->username = 'elenasommer';
        $user->email = 'elena@test.at';
        $user->is_searching = false;
        $user->password = bcrypt('test123');

        $user->save();

        $booking=Booking::all()->pluck('id');
        $user->bookings()->sync($booking);

        $user->save();

        $user1 = new User;
        $user1->firstname = 'Michael';
        $user1->lastname = 'Silber';
        $user1->username = 'michaelsilber';
        $user1->email = 'michael@test.at';
        $user1->is_searching = true;
        $user1->password = bcrypt('test123');

        $user1->save();

        $booking=Booking::all()->pluck('id');
        $user1->bookings()->sync($booking);

        $user1->save();
    }
}

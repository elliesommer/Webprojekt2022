<?php

namespace Database\Seeders;

use App\Models\Booking;
use App\Models\Entry;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Seeder;

class BookingsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $booking = new Booking;
        $booking->day = Carbon::createFromFormat("Y.m.d", "2022.05.01");
        $booking->from = Carbon::createFromTime(16, 00, 00, "Europe/Vienna");
        $booking->to = Carbon::createFromTime(17, 45, 00, "Europe/Vienna");

        $entry_id = Entry::all()->first();
        $booking->entry()->associate($entry_id);

        $booking->save();

        $user=User::all()->pluck('id');
        $booking->users()->sync($user);

        $booking->save();
    }
}

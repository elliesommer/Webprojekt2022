<?php

namespace Database\Seeders;

use App\Models\Entry;
use App\Models\Booking;
use App\Models\User;
use Illuminate\Database\Seeder;



class EntriesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $entry = new Entry;
        $entry->title = "OOP Nachhilfe für Erstsemestrige";
        $entry->description = "Hallo! Ich biete Nachhilfe in Objektorientierter Programmierung - Preis: 8€ pro Stunde";
        $entry->subject = "Objektorientierte Programmierung";
        $entry->is_offer = true;

        //get the first user
        $user = User::all()->first();
        $entry->user()->associate($user);

        //save to db
        $entry->save();

        //get bookings
        $booking=Booking::all()->pluck('id');
        $entry->bookings()->saveMany($booking);

        //save to db
        $entry->save();

    }
}

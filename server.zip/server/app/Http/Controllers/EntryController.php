<?php

namespace App\Http\Controllers;

use App\Models\Entry;
use App\Models\User;
use App\Models\Booking;
use App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Database\Eloquent;
use Illuminate\Support\Facades\DB;
use Psy\Util\Json;


class EntryController extends Controller
{
    public function index(){
        //load all entries and related objects
        $entries = Entry::with(['bookings', 'user'])->get();
        return $entries;
    }

    //find entry by id
    public function findBySubject(int $subject){
        $entry = Entry::where('id', $subject)
            ->with(['bookings', 'user'])->first();
        return $entry != null ? response()->json($entry, 200) : response()->json(null, 200);
    }

    //find user by id
    public function getUser(int $id){
        $user = User::where('id', $id)->first();
        return $user != null ? response()->json($user, 200) : response()->json(null, 200);
    }

    //check if subject exists
    public function checkSubject(string $subject){
        $entry = Entry::where('subject', $subject)->first();
        return $entry != null ? response()->json(true, 200) : response()->json(false, 200);
    }

    //find entry by search term
    public function findBySearchTerm(string $searchTerm){
        $entry = Entry::with(['bookings', 'user'])
            ->where('title', 'LIKE', '%' . $searchTerm. '%')
            ->orWhere('description', 'LIKE', '%' . $searchTerm. '%')
            ->orWhere('subject', 'LIKE', '%' . $searchTerm. '%')

            //search term in users name/username
            ->orWhereHas('user', function ($query) use ($searchTerm) {
                $query->where('firstname', 'LIKE', '%' . $searchTerm. '%')
                    ->orWhere('lastname', 'LIKE', '%' . $searchTerm. '%')
                    ->orWhere('username', 'LIKE', '%' . $searchTerm. '%')
                    ->orWhere('description', 'LIKE', '%' . $searchTerm. '%');
            })->get();
        return $entry;
    }

    //create new entry
    public function save(Request $request) : JsonResponse {
        $request = $this->parseRequest($request);

        DB::beginTransaction();
        try {
            $entry = Entry::create($request->all());

            //save bookings
            if (isset($request['bookings']) && is_array($request['bookings'])) {
                foreach ($request['bookings'] as $bkg) {
                    $booking = Booking::firstOrNew(
                        ['day'=>$bkg['day'], 'from'=>$bkg['from'], 'to'=>$bkg['to'], 'is_booked'=>$bkg['is_booked']]);
                    $entry->bookings()->save($booking);
                }
            }

            //save user
            if (isset($request['user']) && is_array($request['user'])) {
                foreach ($request['user'] as $usr) {
                    $user = User::firstOrNew(['firstname'=>$usr['firstname'], 'lastName'=>$usr['lastname'],
                        'username'=>$usr['username'], 'email'=>$usr['email']]);
                    $entry->user()->save($user);
                }
            }

            DB::commit();
            return response()->json($entry, 201);
        }
        catch (\Exception $e) {
            DB::rollBack();
            return response()->json("saving entry failed: " . $e->getMessage(), 420);
        }
    }

    public function update(Request $request, int $id) : JsonResponse {
        DB::beginTransaction();
        try {
            $entry = Entry::with(['bookings', 'user'])
                ->where('id', $id)->first();
            if($entry != null) {
                $request = $this->parseRequest($request);
                $entry->update($request->all());

                //delete all old bookings
                $entry->bookings()->delete();

                //save bookings
                if(isset($request['bookings']) && is_array($request['bookings'])){
                    foreach ($request['bookings'] as $bkg) {
                        $booking = Booking::firstOrNew(
                            ['day'=>$bkg['day'], 'from'=>$bkg['from'], 'to'=>$bkg['to'], 'is_booked'=>$bkg['is_booked']]);
                        $entry->bookings()->save($booking);
                    }
                }
            }
            DB::commit();
            $entry1 = Entry::with(['user', 'bookings'])->where('id', $id)->first();
            //return valid html response
            return response()->json($entry1, 201);
        }
        catch (\Exception $e){
            DB::rollBack();
            return response()->json("updating entry failed: " . $e->getMessage(), 420);
        }
    }

    public function delete(int $id) : JsonResponse {
        $entry = Entry::where('id', $id)->first();
        if($entry != null){
            $entry->delete();
        }
        else
            throw new \Exception("entry couldn't be deleted - it does not exist");
        return response()->json('entry (' . $id . ') successfully deleted', 200);
    }

    private function parseRequest(Request $request) : Request {
        $date = new \DateTime($request->published);
        $request['published'] = $date;
        return $request;
    }

    public function updateBooking(Request $request, int $id): JsonResponse
    {
        DB::beginTransaction();
        try {
            $booking = Booking::where('id', $id)->first();
            if ($booking != null) {
                $booking['is_booked'] = true;
                $user = [];
                array_push($user, $request['user_id']);
                $booking->users()->sync($user);
                $booking->update($request->all());
                $booking->save();
            }
            DB::commit();
            $booking1 = Booking::where('id', $id)->first();
            // return a vaild http response
            return response()->json($booking1, 201);
        } catch (Exception $e) {
            // rollback all queries
            DB::rollBack();
            return response()->json("updating booking failed: " . $e->getMessage(), 420);
        }
    }
}

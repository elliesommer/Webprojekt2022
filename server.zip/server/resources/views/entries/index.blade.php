<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<ul>
    @foreach ($entries as $entry)
        <li><a href="entries/{{$entry->id}}">
                {{$entry->title}}</a></li>
@endforeach
</ul>
</body>
</html>

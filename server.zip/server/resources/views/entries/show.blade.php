<!DOCTYPE html>
<html>
<head>
    <title></title>
</head>
<body>
<ul>
    <h1>{{$entry->title}}</h1>
    <p>{{$entry->description}}</p>
    <p>{{$entry->subject}}</p>
</ul>
</body>
</html>
